import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { ConfigService } from '@nestjs/config';
import {
  Organization,
  User,
  Project,
  Activity,
  Comment,
  AuditLog,
  Task,
  Board,
  Approval,
  TaskHistory,
  TaskComment,
  TaskAttachment,
} from '../entities';
import { StatusConfiguration } from '../entities/status-configuration.entity';

export const getDatabaseConfig = (configService: ConfigService): TypeOrmModuleOptions => {
  // Support both MySQL connection URL and individual parameters
  const databaseUrl = configService.get('DATABASE_URL');

  if (databaseUrl) {
    // Parse MySQL connection URL: mysql://user:password@host:port/database
    const url = new URL(databaseUrl);
    return {
      type: 'mysql',
      host: url.hostname,
      port: parseInt(url.port) || 3306,
      username: url.username,
      password: url.password,
      database: url.pathname.slice(1), // Remove leading slash
      ssl: url.searchParams.get('ssl') === 'true' ? { rejectUnauthorized: false } : false,
      entities: [
        Organization,
        User,
        Project,
        Activity,
        Comment,
        AuditLog,
        Task,
        Board,
        Approval,
        TaskHistory,
        TaskComment,
        TaskAttachment,
        StatusConfiguration,
      ],
      synchronize: configService.get('NODE_ENV') !== 'production',
      dropSchema: configService.get('DB_DROP_SCHEMA') === 'true',
      logging: configService.get('NODE_ENV') === 'development',
    };
  }

  // Fallback to individual parameters for local development
  return {
    type: 'mysql',
    host: configService.get('DB_HOST', 'localhost'),
    port: configService.get('DB_PORT', 3306),
    username: configService.get('DB_USERNAME', 'root'),
    password: configService.get('DB_PASSWORD', 'password'),
    database: configService.get('DB_NAME', 'pactivities'),
    entities: [
      Organization,
      User,
      Project,
      Activity,
      Comment,
      AuditLog,
      Task,
      Board,
      Approval,
      TaskHistory,
      TaskComment,
      TaskAttachment,
      StatusConfiguration,
    ],
    synchronize: configService.get('NODE_ENV') !== 'production',
    dropSchema: configService.get('DB_DROP_SCHEMA') === 'true',
    logging: configService.get('NODE_ENV') === 'development',
  };
};
